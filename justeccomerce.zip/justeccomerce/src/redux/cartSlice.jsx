import { createSlice } from "@reduxjs/toolkit";

const cartSlice = createSlice({
    name: "cart",
    initialState: {
        cartItems: [],
    },
    reducers: {
        addToCart: (state, action) => {
            const findIndex = state.cartItems.findIndex((item) => item.id === action.payload.id);
            if (findIndex >= 0) {
                state.cartItems[findIndex].qty += 1;
            } else {
                let newEntry = { ...action.payload, qty: 1 };
                state.cartItems = [...state.cartItems, newEntry];
            }
        },
        decreaseQuantity: (state, action) => {
            let findIndex = state.cartItems.findIndex((item) => item.id === action.payload.id);
            if (findIndex >= 0 && state.cartItems[findIndex].qty > 1) {
                state.cartItems[findIndex].qty -= 1;
            }
        },
        removeFromCart: (state, action) => {
            state.cartItems = state.cartItems.filter(
                (item) => item.id !== action.payload.id
            );
        },
        clearCart: (state) => {
            state.cartItems = [];
        }
    },
});

export const { addToCart, decreaseQuantity, removeFromCart, clearCart } = cartSlice.actions;

export default cartSlice.reducer;
