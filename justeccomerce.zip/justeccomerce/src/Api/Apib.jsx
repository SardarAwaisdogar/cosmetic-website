export const Apib = 
    [
        {
            "id": 2001,
            "title": "Samsung galaxy 5",
            "price": 500,
            "previousPrice": 620,
            "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
            "category": "watch",
            "image": "https://i.ibb.co/pZHdhK1/samsunggalaxy5.jpg",
            "isNew": true,
            "brand": "Samsung",
            "qty": 0
            },
            {
            "id": 2002,
            "title": "Apple watch ultra",
            "price": 850.99,
            "previousPrice": 980.99,
            "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
            "category": "watch",
            "image": "https://i.ibb.co/k2GT5xP/apple-watch-ultra-1.jpg",
            "isNew": true,
            "brand": "Apple",
            "qty": 0
            },
            {
            "id": 2003,
            "title": "Coros Apex Premium",
            "price": 450,
            "previousPrice": 480,
            "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
            "category": "watch",
            "image": "https://i.ibb.co/LJJc7Vn/coros-apex-premium-multisport-1.jpg",
            "isNew": true,
            "brand": "Coros-apex",
            "qty": 0
            },
            {
            "id": 2004,
            "title": "Apple Watch SE",
            "price": 999.99,
            "previousPrice": 1050,
            "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
            "category": "watch",
            "image": "https://i.ibb.co/Pjff2JW/apple-watch-se-1.jpg",
            "isNew": true,
            "brand": "Apple",
            "qty": 0
            },
            {
            "id": 2005,
            "title": "Apple watch 8",
            "price": 850,
            "previousPrice": 860,
            "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
            "category": "watch",
            "image": "https://i.ibb.co/4874bqD/apple-watch-series-8-1.jpg",
            "isNew": true,
            "brand": "Apple",
            "qty": 0
            },
            {
            "id": 2006,
            "title": "Apple watch 7",
            "price": 780,
            "previousPrice": 800,
            "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
            "category": "watch",
            "image": "https://i.ibb.co/vmctpHt/apple-watch-series-7-1.jpg",
            "isNew": true,
            "brand": "Apple",
            "qty": 0
            },
            {
            "id": 2007,
            "title": "Fossil Gen 6",
            "price": 950,
            "previousPrice": 780,
            "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
            "category": "watch",
            "image": "https://i.ibb.co/yFPfT6G/fossil-gen-6-1.jpg",
            "isNew": true,
            "brand": "Fossil",
            "qty": 0
            },
            {
            "id": 2008,
            "title": "Fossil Gen 6 Leather",
            "price": 1100,
            "previousPrice": 1150.99,
            "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
            "category": "watch",
            "image": "https://i.ibb.co/G7z0gxF/fossil-gen-6-leather-1.jpg",
            "isNew": true,
            "brand": "Fossil",
            "qty": 0
            },
            {
            "id": 2009,
            "title": "Google Fitbit",
            "price": 650.5,
            "previousPrice": 690,
            "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
            "category": "watch",
            "image": "https://i.ibb.co/0V9qQwQ/google-fitbit-sense-2-1.jpg",
            "isNew": true,
            "brand": "Google",
            "qty": 0
            },
            {
            "id": 2010,
            "title": "Huawei 7",
            "price": 780,
            "previousPrice": 800,
            "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
            "category": "watch",
            "image": "https://i.ibb.co/z5b76Lf/huawei-band-7-1.jpg",
            "isNew": true,
            "brand": "Huawei",
            "qty": 0
            },
            {
            "id": 2011,
            "title": "Google Fitbit",
            "price": 650.5,
            "previousPrice": 690,
            "description": "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
            "category": "watch",
            "image": "https://i.ibb.co/0V9qQwQ/google-fitbit-sense-2-1.jpg",
            "isNew": true,
            "brand": "Google",
            "qty": 0
            },
        {
        "id": 12,
        "title": "WD 4TB Gaming Drive Works with Playstation 4 Portable External Hard Drive",
        "price": 114,
        "description": "Expand your PS4 gaming experience, Play anywhere Fast and easy, setup Sleek design with high capacity, 3-year manufacturer's limited warranty",
        "category": "electronics",
        "image": "/Image/watch1.jpg",
        "rating": {
        "rate": 4.8,
        "count": 400
        }
        },
        {
        "id": 13,
        "title": "Acer SB220Q bi 21.5 inches Full HD (1920 x 1080) IPS Ultra-Thin",
        "price": 599,
        "description": "21. 5 inches Full HD (1920 x 1080) widescreen IPS display And Radeon free Sync technology. No compatibility for VESA Mount Refresh Rate: 75Hz - Using HDMI port Zero-frame design | ultra-thin | 4ms response time | IPS panel Aspect ratio - 16: 9. Color Supported - 16. 7 million colors. Brightness - 250 nit Tilt angle -5 degree to 15 degree. Horizontal viewing angle-178 degree. Vertical viewing angle-178 degree 75 hertz",
        "category": "electronics",
        "image": "/public/Image/watch2.jpg",
        "rating": {
        "rate": 2.9,
        "count": 250
        }
        },
        {
        "id": 14,
        "title": "Samsung 49-Inch CHG90 144Hz Curved Gaming Monitor (LC49HG90DMNXZA) – Super Ultrawide Screen QLED ",
        "price": 999.99,
        "description": "49 INCH SUPER ULTRAWIDE 32:9 CURVED GAMING MONITOR with dual 27 inch screen side by side QUANTUM DOT (QLED) TECHNOLOGY, HDR support and factory calibration provides stunningly realistic and accurate color and contrast 144HZ HIGH REFRESH RATE and 1ms ultra fast response time work to eliminate motion blur, ghosting, and reduce input lag",
        "category": "electronics",
        "image": "/public/Image/watch3.jpg",
        "rating": {
        "rate": 2.2,
        "count": 140
        }
        },
        {
        "id": 15,
        "title": "BIYLACLESEN Women's 3-in-1 Snowboard Jacket Winter Coats",
        "price": 56.99,
        "description": "Note:The Jackets is US standard size, Please choose size as your usual wear Material: 100% Polyester; Detachable Liner Fabric: Warm Fleece. Detachable Functional Liner: Skin Friendly, Lightweigt and Warm.Stand Collar Liner jacket, keep you warm in cold weather. Zippered Pockets: 2 Zippered Hand Pockets, 2 Zippered Pockets on Chest (enough to keep cards or keys)and 1 Hidden Pocket Inside.Zippered Hand Pockets and Hidden Pocket keep your things secure. Humanized Design: Adjustable and Detachable Hood and Adjustable cuff to prevent the wind and water,for a comfortable fit. 3 in 1 Detachable Design provide more convenience, you can separate the coat and inner as needed, or wear it together. It is suitable for different season and help you adapt to different climates",
        "category": "women's clothing",
        "image": "/public/Image/watch4.jpg",
        "rating": {
        "rate": 2.6,
        "count": 235
        }
        },
        {
        "id": 16,
        "title": "Lock and Love Women's Removable Hooded Faux Leather Moto Biker Jacket",
        "price": 29.95,
        "description": "100% POLYURETHANE(shell) 100% POLYESTER(lining) 75% POLYESTER 25% COTTON (SWEATER), Faux leather material for style and comfort / 2 pockets of front, 2-For-One Hooded denim style faux leather jacket, Button detail on waist / Detail stitching at sides, HAND WASH ONLY / DO NOT BLEACH / LINE DRY / DO NOT IRON",
        "category": "women's clothing",
        "image": "/Image/watch4.webp",
        "rating": {
        "rate": 2.9,
        "count": 340
        }
        },
        {
        "id": 17,
        "title": "Rain Jacket Women Windbreaker Striped Climbing Raincoats",
        "price": 39.99,
        "description": "Lightweight perfet for trip or casual wear---Long sleeve with hooded, adjustable drawstring waist design. Button and zipper front closure raincoat, fully stripes Lined and The Raincoat has 2 side pockets are a good size to hold all kinds of things, it covers the hips, and the hood is generous but doesn't overdo it.Attached Cotton Lined Hood with Adjustable Drawstrings give it a real styled look.",
        "category": "women's clothing",
        "image": "/Image/watch6.png",
        "rating": {
        "rate": 3.8,
        "count": 679
        }
        },
        {
        "id": 18,
        "title": "MBJ Women's Solid Short Sleeve Boat Neck V ",
        "price": 9.85,
        "description": "95% RAYON 5% SPANDEX, Made in USA or Imported, Do Not Bleach, Lightweight fabric with great stretch for comfort, Ribbed on sleeves and neckline / Double stitching on bottom hem",
        "category": "women's clothing",
        "image": "/public/Image/watch7.png",
        "rating": {
        "rate": 4.7,
        "count": 130
        }
        },
        {
        "id": 19,
        "title": "Opna Women's Short Sleeve Moisture",
        "price": 7.95,
        "description": "100% Polyester, Machine wash, 100% cationic polyester interlock, Machine Wash & Pre Shrunk for a Great Fit, Lightweight, roomy and highly breathable with moisture wicking fabric which helps to keep moisture away, Soft Lightweight Fabric with comfortable V-neck collar and a slimmer fit, delivers a sleek, more feminine silhouette and Added Comfort",
        "category": "women's clothing",
        "image": "/Image/watch8.jpg",
        "rating": {
        "rate": 4.5,
        "count": 146
        }
        },
        {
        "id": 20,
        "title": "DANVOUY Womens T Shirt Casual Cotton Short",
        "price": 12.99,
        "description": "95%Cotton,5%Spandex, Features: Casual, Short Sleeve, Letter Print,V-Neck,Fashion Tees, The fabric is soft and has some stretch., Occasion: Casual/Office/Beach/School/Home/Street. Season: Spring,Summer,Autumn,Winter.",
        "category": "women's clothing",
        "image": "/Image/watch9.jpg",
        "rating": {
        "rate": 3.6,
        "count": 145
        }
        }
        ]
