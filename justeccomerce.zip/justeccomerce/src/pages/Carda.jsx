import { Link } from "react-router-dom"
import { Apia } from "../Api/Apia"


const Carda = () => {
  return (
   
   <section className="text-gray-600 body-font">
  <div className="container px-5 py-24 mx-auto">
   
    <div className="flex flex-wrap -m-4">
      {
        Apia.map((x)=>{
          return(
            <div key={x.id} className="xl:w-1/4 md:w-1/2 p-4 text-center">
        <div  className="bg-gray-100 p-6 rounded-lg">
          <Link to={`/product/${x.id}`}><img className="h-60 rounded w-full object-cover object-center mb-6" src={x.image} alt="content" /></Link>
          <h3 className="tracking-widest text-indigo-500 text-xs font-medium title-font">SUBTITLE</h3>
          <h2 className="text-lg text-gray-900 font-medium title-font mb-4">San Francisco</h2>
          <p className="leading-relaxed text-base">Fingerstache flexitarian street art 8-bit waistcoat. Distillery hexagon disrupt edison bulbche.</p>
        </div>
      </div>
          )
        })
      }
      
    </div>
  </div>
</section>



   
  
  )
}



export default Carda



// const Home = () => {
//   return (
//     <>
//       {/* Slider-Section */}
//       <div className="relative">
//         <div className="sticky top-0 h-screen flex flex-col items-center justify-center bg-gradient-to-b from-green-200 to-blue-200">
//           <h2 className="text-4xl font-bold">The First slide</h2>
//           <p className="mt-2">Scroll Down for next slide</p>
//         </div>
//         <div className="sticky top-0 h-screen flex flex-col items-center justify-center bg-gradient-to-b from-indigo-800 to-purple-800 text-white">
//           <h2 className="text-4xl font-bold">The Second slide</h2>
//           <p className="mt-2">Scroll Down for next slide</p>
//         </div>
//         <div className="sticky top-0 h-screen flex flex-col items-center justify-center bg-gradient-to-b from-purple-800 to-pink-800 text-white">
//           <h2 className="text-4xl font-bold">The Third slide</h2>
//           <p className="mt-2">Scroll Down</p>
//         </div>
//         <div className="sticky top-0 h-screen flex flex-col items-center justify-center bg-gradient-to-b from-blue-200 to-indigo-100 text-black">
//           <h2 className="text-4xl font-bold">The Fourth slide</h2>
//         </div>
//       </div>

//       {/* Card-Section */}
//       <div className="max-w-screen-xl mx-auto p-5 sm:p-10 md:p-16">
//         <div className="grid grid-cols-1 md:grid-cols-3 sm:grid-cols-2 gap-10">
//           <div className="border-r border-b border-l border-gray-400 lg:border-t lg:border-gray-400 bg-white rounded-b lg:rounded-b-none lg:rounded-r flex flex-col justify-between leading-normal">
//           <Link to="/Carda"><img src="https://images.pexels.com/photos/1181467/pexels-photo-1181467.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500" className="w-full mb-3" /></Link>
//             <div className="p-4 pt-2">
//               <div className="mb-8">
//                 <p className="text-sm text-gray-600 flex items-center">
//                   <svg className="fill-current text-gray-500 w-3 h-3 mr-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
//                     <path d="M4 8V6a6 6 0 1 1 12 0v2h1a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2v-8c0-1.1.9-2 2-2h1zm5 6.73V17h2v-2.27a2 2 0 1 0-2 0zM7 6v2h6V6a3 3 0 0 0-6 0z"></path>
//                   </svg>
//                   Members only
//                 </p>
//                 <a href="#" className="text-gray-900 font-bold text-lg mb-2 hover:text-indigo-600 inline-block">
//                   Can coffee make you a better developer?
//                 </a>
//                 <p className="text-gray-700 text-sm">
//                   Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus quia, nulla! Maiores et perferendis eaque, exercitationem praesentium nihil.
//                 </p>
//               </div>
//               <div className="flex items-center">
//                 <a href="#"><img className="w-10 h-10 rounded-full mr-4" src="https://tailwindcss.com/img/jonathan.jpg" alt="Avatar of Jonathan Reinink" /></a>
//                 <div className="text-sm">
//                   <a href="#" className="text-gray-900 font-semibold leading-none hover:text-indigo-600">Jonathan Reinink</a>
//                   <p className="text-gray-600">Aug 18</p>
//                 </div>
//               </div>
//             </div>
//           </div>
//           <div className="border-r border-b border-l border-gray-400 lg:border-t lg:border-gray-400 bg-white rounded-b lg:rounded-b-none lg:rounded-r flex flex-col justify-between leading-normal">
//             <img src="https://images.pexels.com/photos/1181467/pexels-photo-1181467.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500" className="w-full mb-3" />
//             <div className="p-4 pt-2">
//               <div className="mb-8">
//                 <p className="text-sm text-gray-600 flex items-center">
//                   <svg className="fill-current text-gray-500 w-3 h-3 mr-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
//                     <path d="M4 8V6a6 6 0 1 1 12 0v2h1a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2v-8c0-1.1.9-2 2-2h1zm5 6.73V17h2v-2.27a2 2 0 1 0-2 0zM7 6v2h6V6a3 3 0 0 0-6 0z"></path>
//                   </svg>
//                   Members only
//                 </p>
//                 <a href="#" className="text-gray-900 font-bold text-lg mb-2 hover:text-indigo-600 inline-block">
//                   Can coffee make you a better developer?
//                 </a>
//                 <p className="text-gray-700 text-sm">
//                   Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus quia, nulla! Maiores et perferendis eaque, exercitationem praesentium nihil.
//                 </p>
//               </div>
//               <div className="flex items-center">
//                 <a href="#"><img className="w-10 h-10 rounded-full mr-4" src="https://tailwindcss.com/img/jonathan.jpg" alt="Avatar of Jonathan Reinink" /></a>
//                 <div className="text-sm">
//                   <a href="#" className="text-gray-900 font-semibold leading-none hover:text-indigo-600">Jonathan Reinink</a>
//                   <p className="text-gray-600">Aug 18</p>
//                 </div>
//               </div>
//             </div>
//           </div>
//           <div className="border-r border-b border-l border-gray-400 lg:border-t lg:border-gray-400 bg-white rounded-b lg:rounded-b-none lg:rounded-r flex flex-col justify-between leading-normal">
//             <img src="https://images.pexels.com/photos/1181467/pexels-photo-1181467.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500" className="w-full mb-3" />
//             <div className="p-4 pt-2">
//               <div className="mb-8">
//                 <p className="text-sm text-gray-600 flex items-center">
//                   <svg className="fill-current text-gray-500 w-3 h-3 mr-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
//                     <path d="M4 8V6a6 6 0 1 1 12 0v2h1a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2v-8c0-1.1.9-2 2-2h1zm5 6.73V17h2v-2.27a2 2 0 1 0-2 0zM7 6v2h6V6a3 3 0 0 0-6 0z"></path>
//                   </svg>
//                   Members only
//                 </p>
//                 <a href="#" className="text-gray-900 font-bold text-lg mb-2 hover:text-indigo-600 inline-block">
//                   Can coffee make you a better developer?
//                 </a>
//                 <p className="text-gray-700 text-sm">
//                   Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus quia, nulla! Maiores et perferendis eaque, exercitationem praesentium nihil.
//                 </p>
//               </div>
//               <div className="flex items-center">
//                 <a href="#"><img className="w-10 h-10 rounded-full mr-4" src="https://tailwindcss.com/img/jonathan.jpg" alt="Avatar of Jonathan Reinink" /></a>
//                 <div className="text-sm">
//                   <a href="#" className="text-gray-900 font-semibold leading-none hover:text-indigo-600">Jonathan Reinink</a>
//                   <p className="text-gray-600">Aug 18</p>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//        {/* Half-Section */}
      
// <div className="z-30 relative items-center justify-center w-full h-full overflow-auto">
//   <div className="inset-0 h-screen bg-cover bg-center" style={{backgroundImage: 'url("https://wallpapercave.com/wp/wp6689710.jpg")'}}>
//   </div>
//   <div className="absolute inset-0 z-20 flex items-center justify-center h-screen w-full bg-gray-900 bg-opacity-75" />
//   <div className="absolute inset-0  z-30  flex flex-col items-center justify-center">
//     <div className="shadow-2xl rounded-lg w-4/5 h-96 bg-cover bg-center" style={{backgroundImage: 'url("https://wallpapercave.com/wp/wp6689710.jpg")'}}>
//       <div className="grid grid-cols-12 gap-1">
//         <div className="relative my-6 px-8 col-span-12 sm:col-span-12 md:col-span-7 lg:col-span-7 xxl:col-span-7">
//           <div className="border-l-4 border-gray-400 py-20 px-5 mx-2 absolute left-0">
//             <p className="italic text-white text-xl md:text-4xl lg:text-6xl uppercase text-center  font-semibold ">
//               The Mysteries Of The Forest
//             </p>
//           </div>
//           <div className="text-gray-400 font-semibold text-xl mb-4">07</div>
//           <div className="absolute border-gray-400 border-t-4 bottom-0 py-1 px-4 w-4/5" />
//         </div>
//         <div className="col-span-12 sm:col-span-12 md:col-span-5 lg:col-span-5 xxl:col-span-5">
//           <div className="relative bg-pink-900 h-full md:h-96 w-full bg-opacity-50 rounded-tr-lg rounded-br-lg">
//             <div className="p-8">
//               <p className="text-white text-xs md:text-sm lg:text-xl mb-4">
//                 Forests are truly amazing places. 
//                 Combining impressive biodiversity with natural beauty, 
//                 the woods of the world can be both captivating and perplexing. 
//                 A hike through a forest can be a relaxing way to pass an afternoon or, 
//                 sometimes, a glimpse into the unknown.
//               </p>
//               <div className="bottom-0 absolute p-2 right-0">
//                 <button className="opacity-75 bg-gray-100 hover:bg-pink-900 hover:text-white text-sm font-bold py-2 px-4 rounded inline-flex items-center">
//                   <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 9l3 3m0 0l-3 3m3-3H8m13 0a9 9 0 11-18 0 9 9 0 0118 0z" />
//                   </svg>
//                   <span>LEARN MORE</span>
//                 </button> 
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   </div>
// </div>


//     </>
//   );
// };

// export default Home;
