import { Route, Routes } from "react-router";
import Navbar from "./componenets/Navbar";
import Home from "./pages/Home";

import Carda from "./pages/Carda";
import Cardb from "./pages/Cardb";
import Cardc from "./pages/Cardc";
import Carde from "./pages/Carde";
import Cardf from "./pages/Cardf";
import Cardg from "./pages/Cardg";
import Detailpage from "./Detailpage/Detailpage";

import Detailpagec from "./Detailpage/Detailpagec";
import Detailpagee from "./Detailpage/Detailpagee";
import Detailpagef from "./Detailpage/Detailpagef";
import Detailpageg from "./Detailpage/Detailpageg";
import Detailpageb from "./Detailpage/Detailpageb";
import Shoppingcart from "./Add to cart/Shoppingcart";

export default function App() {
  return (
    <>
    <Navbar/>

    <Routes>
    <Route path="/" element={<Home/>}></Route>
    <Route path="/Carda" element={<Carda/>}></Route>
    <Route path="/Cardb" element={<Cardb/>}></Route>
    <Route path="/Cardc" element={<Cardc/>}></Route>
    <Route path="/Carde" element={<Carde/>}></Route>
    <Route path="/Cardf" element={<Cardf/>}></Route>
    <Route path="/Cardg" element={<Cardg/>}></Route>
    <Route path="/Product/:id" element = {<Detailpage/>}></Route>
    <Route path="/Productb/:id" element = {<Detailpageb/>}></Route>
    <Route path="/Productc/:id" element = {<Detailpagec/>}></Route>
    <Route path="/Producte/:id" element = {<Detailpagee/>}></Route>
    <Route path="/Productf/:id" element = {<Detailpagef/>}></Route>
    <Route path="/Productg/:id" element = {<Detailpageg/>}></Route>
    <Route path="/Shoppingcart" element = {<Shoppingcart/>}></Route>
    </Routes>
    </>
  )
}