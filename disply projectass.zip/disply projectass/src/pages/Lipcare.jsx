
import { Link } from 'react-router-dom'
import { lip } from '../lib/lip'


const Lipcare = () => {
  return (
    <div>
     
    <section className="text-gray-600 body-font text-center">

    <div className="container px-5 py-24 mx-auto">
      
      <div className="flex flex-wrap -m-4">
     
     
        {lip.map((x)=>{
          return(
              <div className="xl:w-1/4 w-full md:w-1/2 p-4 text-white cursor-pointer"  key={x.id}>
          <div className=" p-6 rounded-lg bg-[#399918]">
          <Link to={`/lipdetail/${x._id}`}><img className="h-40 rounded w-full object-cover object-center  mb-6 hover:scale-[1.2] transition-all" src={x.thumbnail}alt="" style={{aspectRatio:3/2, objectFit:"contain"}}/></Link>
          
            <h2 className="text-lg  font-medium title-font mb-4">{x.title.slice(0,15)}</h2>
            <p className="leading-relaxed text-base">{x.description.slice(0,45)}</p>
            <p className="leading-relaxed text-base">Rs:{x.price}</p>
           
          </div>
        </div>
          )
        }
      
      )}
      </div>
    </div>
   
      

  </section>
  </div>
  )
}

export default Lipcare
