import { useState } from "react";
import { useParams } from "react-router-dom";
import { skin } from "../lib/skin";
import { useDispatch } from "react-redux";
import { addCart } from "../redux/cartSlice";


const Skincaredetail = () => {

    const {id}= useParams();
    const dispatch = useDispatch();
    const add = (getdata) => {
      dispatch(addCart(getdata));
    };
  

 
 
  const detail = skin.find((x)=>x.id ==id)

  const [images, setImages] = useState(detail.thumbnail)
const changeImage = (x)=>{
  setImages(x)
}
console.log(detail)

  

  
  return (
   <div className="font-sans cursor-pointer ">
  <div className="p-4 lg:max-w-7xl max-w-xl max-lg:mx-auto ">
    <div className="grid items-start grid-cols-1 lg:grid-cols-5 gap-12 bg-[#921A40] text-white">
      <div className="min-h-[500px] lg:col-span-3 bg-gradient-to-tr  from-[#F8C794] via-[#FFE0B5] to-[#FFF2D7] rounded-lg w-full lg:sticky top-0 text-center p-6">
        <img src={images} alt="Product" className="w-3/5 rounded object-cover mx-auto py-6" />
        <hr className="border-white border my-6" />
        <div className="flex flex-wrap gap-x-5 justify-center mx-auto">
        {detail.images.map((x)=>
             <img className="xl:w-1/5 w-full  mx-auto" src={x} alt="content" onClick={()=>changeImage(x)} />
         )}
          
         
        </div>
      </div>
      <div className="lg:col-span-2">
        <h2 className="text-2xl font-bold ">{detail.title}</h2>
        <div className="flex flex-wrap gap-4 mt-4">
          <p className=" text-xl font-bold">${detail.previousPrice}</p>
          <p className=" text-xl"><strike>${detail.price}</strike> <span className="text-sm ml-1">Discount</span></p>
        </div>
        <div className="flex space-x-2 mt-4">
          <svg className="w-5 fill-orange-400" viewBox="0 0 14 13" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M7 0L9.4687 3.60213L13.6574 4.83688L10.9944 8.29787L11.1145 12.6631L7 11.2L2.8855 12.6631L3.00556 8.29787L0.342604 4.83688L4.5313 3.60213L7 0Z" />
          </svg>
          <svg className="w-5 fill-orange-400" viewBox="0 0 14 13" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M7 0L9.4687 3.60213L13.6574 4.83688L10.9944 8.29787L11.1145 12.6631L7 11.2L2.8855 12.6631L3.00556 8.29787L0.342604 4.83688L4.5313 3.60213L7 0Z" />
          </svg>
          <svg className="w-5 fill-orange-400" viewBox="0 0 14 13" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M7 0L9.4687 3.60213L13.6574 4.83688L10.9944 8.29787L11.1145 12.6631L7 11.2L2.8855 12.6631L3.00556 8.29787L0.342604 4.83688L4.5313 3.60213L7 0Z" />
          </svg>
          <svg className="w-5 fill-orange-400" viewBox="0 0 14 13" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M7 0L9.4687 3.60213L13.6574 4.83688L10.9944 8.29787L11.1145 12.6631L7 11.2L2.8855 12.6631L3.00556 8.29787L0.342604 4.83688L4.5313 3.60213L7 0Z" />
          </svg>
          <svg className="w-5 fill-[#CED5D8]" viewBox="0 0 14 13" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M7 0L9.4687 3.60213L13.6574 4.83688L10.9944 8.29787L11.1145 12.6631L7 11.2L2.8855 12.6631L3.00556 8.29787L0.342604 4.83688L4.5313 3.60213L7 0Z" />
          </svg>
        </div>
        <div className="mt-8">
          <h3 className="text-xl font-bold ">Description:</h3>
          <ul className="space-y-3 list-disc mt-4 pl-4 text-sm ">
            <li>{detail.description}</li>
           
          </ul>
        </div>
        <button type="button" className="w-full mt-8 px-6 py-3 bg-orange-400 hover:bg-orange-500 text-white text-sm font-semibold rounded-md " onClick={() => add(detail)}>Add to cart</button>
        
      </div>
    </div>
  </div>
</div>

  )
}

export default Skincaredetail
