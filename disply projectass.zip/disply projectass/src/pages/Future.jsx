




const Future = () => {
    return (
    
<div className="pt-8">
<div className="container"><h1 className="bg-indigo-800 text-center text-white p-4">veiew of page</h1> </div>
<section className="text-indigo-900 body-font pt-7">


  <div className="container px-5 py-24 mx-auto">
    <div className="flex flex-wrap -m-4">
      <div className="p-4 md:w-1/3">
      
      </div>
   
      <div className="p-4 md:w-1/3 bg-gray-600 text-white">
        <div className=" overflow-hidden text-center">
        <img className="flex justify-center items-center mx-1" src="/image/heart1.webp" alt="" />
          <div className="p-6">
          
            <h1 className="title-font text-lg font-medium  mb-3">Wishlist is empty.</h1>
            <p className="leading-relaxed mb-3">You dont have any products in the wishlist yet.
            You will find a lot of interesting products on our page.</p>
            <div className="flex items-center flex-wrap ">
              
              <button className="flex m-auto text-white bg-indigo-500 border-0 py-2 px-6 focus:outline-none hover:bg-indigo-600 rounded">Return To Shop</button>
             
          
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

</div>
 


  
    )
  }
  
  export default Future