import { Link } from "react-router-dom"
import { skin } from "../lib/skin"
import Section from "../auth/Section"


const Skincare = () => {
  return (
    <div className="pt-8">
      <h1 className="text-center fs-2 text-indigo-600">Collection</h1>
      <section className="text-gray-600 body-font text-center">
       
    <div className="container px-5 py-24 mx-auto">
  
      
      <div className="flex flex-wrap -m-4">
     
     
        {skin.map((x)=>{
          return(
              <div className="xl:w-1/4 w-full md:w-1/2 p-4 cursor-pointer" key={x.id}>
          <div className="bg-gray-100 p-6 rounded-lg bg-slate-600">
          <Link to={`/skincaredetail/${x.id}`}><img className="h-40 rounded w-full object-cover object-center  mb-6 hover:scale-[1.2] transition-all" src={x.thumbnail}alt="content" style={{aspectRatio:3/2, objectFit:"contain"}} /></Link>
          
        <div className="text-white">
        <h2 className="text-lg  font-medium title-font mb-4">{x.title.slice(0,20)}</h2>
            <p className="leading-relaxed text-base">{x.description.slice(0,40)}</p>
            <p className="leading-relaxed text-base">Rs:{x.price}</p>
          
        </div>
          </div>
        </div>
          )
        }
      
      )}
      </div>
    </div>

      <Section/>
   
  </section>
    </div>
  )
}

export default Skincare
