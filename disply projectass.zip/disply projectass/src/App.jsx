import { Route, Routes } from "react-router-dom"

import Layout from "./components/Layout"
import Skincare from "./pages/Skincare"
import Haircare from "./pages/Haircare"
import Lipcare from "./pages/Lipcare"
import Skincaredetail from "./pages/Skincaredetail"
import ShoppingCard from "./pages/ShoppingCard"
import Hairdetail from "./pages/Hairdetail"
import Lipdetail from "./pages/Lipdetail"
import { Login } from "./auth/Login"
import { Register } from "./auth/Register"
import Home from "./pages/Home"
import Future from "./pages/Future"





const App = () => {
  return (
  <Layout>
 <Routes>
        <Route path="/" element={<Home/>}></Route>
       <Route path="/skincare" element={<Skincare/>}></Route>
       <Route path="/haircare" element={<Haircare/>}></Route>
       <Route path="/hairdetail/:_id" element={<Hairdetail/>}></Route>
       <Route path="/lipcare" element={<Lipcare/>}></Route>
       <Route path="/lipdetail/:_id" element={<Lipdetail/>}></Route>
       <Route path="/skincaredetail/:id" element={<Skincaredetail/>}></Route>
       <Route path="/shop" element={<ShoppingCard/>}></Route>
       <Route path='/login' element={<Login/>}></Route>
       <Route path="/future" element={<Future/>}></Route>
<Route path='/register' element={<Register/>}></Route>
    

   </Routes>
  </Layout>
  )
}

export default App
