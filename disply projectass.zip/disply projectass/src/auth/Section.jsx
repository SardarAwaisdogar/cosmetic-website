

const Section = () => {
  return (
    <section className="text-gray-600 body-font text-center ">
     <div className="container px-2 py-2 mx-auto">
       
     <div>
        <img className="h-100 rounded w-full object-cover object-center mb-6" src="/image/simg2.jpg"alt="content" />
    </div>
     </div>
   
   </section>
   
  )
}

export default Section
