import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  carts: [],
};

const cartSlice = createSlice({
  name: "cart",
  initialState,
  reducers: {
    addCart: (state, action) => {
      let findindex = state.carts.findIndex((item) => item._id === action.payload._id);
      if (findindex >= 0) {
        state.carts[findindex].qty += 1;
      } else {
        let newentry = { ...action.payload, qty: 1 };
        state.carts.push(newentry);
      }
    },
    removesingle: (state, action) => {
      let findindex = state.carts.findIndex((item) => item._id === action.payload._id);
      if (state.carts[findindex].qty > 1) {
        state.carts[findindex].qty -= 1;
      }
    },
    remove: (state, action) => {
      state.carts = state.carts.filter((x) => x._id !== action.payload._id);
    },
  },
});

export default cartSlice.reducer;
export const { addCart, removesingle, remove } = cartSlice.actions;
