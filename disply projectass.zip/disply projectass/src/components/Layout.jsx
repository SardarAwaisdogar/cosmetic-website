import Footer from "./Footer"
import Navbar from "./Navbar"
import Slider from "./Slider"


const Layout = ({children}) => {
  return (
    <div>
      <Navbar/>
      <Slider/>
      
      <div className="min-h-screen">
        {children}

      </div>
      <Footer/>
    </div>
  )
}

export default Layout
