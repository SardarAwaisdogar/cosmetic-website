import AliceCarousel from 'react-alice-carousel';
import 'react-alice-carousel/lib/alice-carousel.css';

const responsive = {
  0: { items: 1 },
  568: { items: 2 },
  1024: { items: 3 },
};

const img = [
  "/image/sliim4.jpg",
  "/image/sliimg1.jpg",
  "/image/sliimg2.jpg",
  "/image/sliimg3.jpg",
  "/image/sliimg4.jpg",
];

const items = img.map((x, index) => (
  <img src={x} alt={`img-${index}`} className='w-full pt-16' key={index} />
));

const Slider = () => {
  return (
  <div className='pt-3'>
      <AliceCarousel
      mouseTracking
      items={items}
      responsive={responsive}
      autoPlay
      autoPlayInterval={2000}
      infinite
      disableDotsControls
      disableButtonsControls
      
    />
    
  </div>
  );
}

export default Slider;
