import React from 'react'
import { product } from '../lib/model/productitem'
import Link from 'next/link'
import AddCart from '../products/AddCartItem'

const Product = ({product}:{product:product}) => {
  return (
      <div className="card bg-base-100 w-80 shadow-xl my-3 cursor-pointer">
  <figure>
   <Link href={`/product/${product.slug}`}>
   <img
      src={product.image}
      alt="Shoes"/>
   </Link>
  </figure>
  <div className="card-body">
    <h2 className="card-title">{product.title.slice(0,20)}</h2>
    <p>{product.description.slice(0,50)}</p>
    <div className="card-actions justify-end">
   
      <AddCart item={{...product, qty:0}}/>
   
    </div>
  </div>
</div>
 
  )
}

export default Product
