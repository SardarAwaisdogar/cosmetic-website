export type OrderItem = {
    title:string
    price:number
    qty:number
    slug:string
    
  
}