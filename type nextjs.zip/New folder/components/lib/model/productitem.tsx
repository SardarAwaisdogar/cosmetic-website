import mongoose from 'mongoose'

const productSchema = new mongoose.Schema(
  {
    slug: { type: String, required: true, unique: true },
    category: { type: String, required: true },
    image: { type: String, required: true },
    price: { type: Number, required: true },
    description: { type: String, required: true },
    color: { type: String, required: true },
    model: { type: String, required: true },
    discount: { type: Number, required: true },
 
  },
  {
    timestamps: true,
  }
)

const ProductModel =
  mongoose.models.Product || mongoose.model('Product', productSchema)

export default ProductModel


export type product = {
    _id?: string,
    title:string,
    image:string,
    price:number,
    description:string,
    category:string,
    model:string,
    slug:string,
    color:string,
    discount:number
}