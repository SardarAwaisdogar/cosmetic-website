import { data } from '@/components/api/data';
import dbConnect from '@/components/lib/Dbconnection';
import ProductModel from '@/components/lib/model/productitem';
import UserModel from '@/components/lib/model/Usermodel';
import { NextRequest, NextResponse } from 'next/server';

export const GET = async (request: NextRequest) => {
  try {
    console.log('Connecting to the database...');
    await dbConnect();
    console.log('Connected to the database');

    const { users, products } = data;

    await UserModel.deleteMany();
    await UserModel.insertMany(users);

    await ProductModel.deleteMany();
    await ProductModel.insertMany(products);

    return NextResponse.json({
      message: 'seeded successfully',
      users,
      products,
    });
  } catch (error) {
    console.error('Error in GET request:', error);
    return NextResponse.json({ message: 'Error seeding database', error: error.message });
  }
};
