import { data } from '@/components/api/data'
import Product from '@/components/product/Product'
import React from 'react'

const Home = () => {
  return (
    <div className='grid md:grid-cols-3 xl:grid-cols-4 place-items-center mx-auto'>
     {
     data.products.map((product)=><Product key={product.slug} product={product}/>)
     }
    </div>
  )
}

export default Home
