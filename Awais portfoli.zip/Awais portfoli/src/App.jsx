import { Route, Routes } from "react-router-dom"
import Layout from "./Component/Layout"
import Home from "./pages/Home"
// import About from "./pages/About"
import Skill from "./pages/Skill"
import Qualification from "./pages/Qualification"
import Project from "./pages/Project"
import Contact from "./pages/Contact"
import Cv from "./pages/Cv"


const App = () => {
  return (
   <Layout>
    <Routes>
      <Route path="/" element={<Home/>}></Route>
      {/* <Route path="/about" element={<About/>}></Route> */}
      <Route path="/skill" element={<Skill/>}></Route>
      <Route path="/qualification" element={<Qualification/>}></Route>
      <Route path="/project" element={<Project/>}></Route>
      <Route path="/contact" element={<Contact/>}></Route>
      <Route path="/cv" element={<Cv/>}></Route>
      
      
    </Routes>
   </Layout>
  )
}

export default App

