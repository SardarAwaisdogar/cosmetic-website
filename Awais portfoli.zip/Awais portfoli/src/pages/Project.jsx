const Project = () => {
  return (
    <div className="pt-24">
      <h1 className="text-center text-gray-900 text-3xl title-font font-medium mb-4">
        Projects - Most Recent Work
      </h1>
      <div className="min-h-screen bg-gray-100 p-3 relative">
        <div className="w-96 mx-auto" style={{ scrollSnapType: 'x mandatory' }}>
          
          {/* First Project */}
          <div>
            <input className="sr-only peer" type="radio" name="carousel" id="carousel-1" defaultChecked />
            <div className="w-96 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white rounded-lg shadow-lg transition-all duration-300 opacity-0 peer-checked:opacity-100 peer-checked:z-10 z-0">
              <img className="rounded-t-lg w-96 h-64" src="/image/card 1.webp" alt="Desi Posh Ladies Outfit" />
              <div className="py-4 px-8">
                <h1 className="hover:cursor-pointer mt-2 text-gray-900 font-bold text-2xl tracking-tight">
                  Desi Posh Ladies
                </h1>
                <p className="hover:cursor-pointer py-3 text-gray-600 leading-6">
                  Desi Posh Ladies Cream Mummy & Me Eid Outfit is a fully stitched ready-to-wear outfit featuring a straight shirt with luxury thread work embroidery.
                </p>
              </div>
              {/* Controls */}
              <div className="absolute top-1/2 w-full flex justify-between z-20">
                <label htmlFor="carousel-5" className="inline-block text-red-600 cursor-pointer -translate-x-5 bg-white rounded-full shadow-md active:translate-y-0.5">
                  {/* Previous Button */}
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm.707-10.293a1 1 0 00-1.414-1.414l-3 3a1 1 0 000 1.414l3 3a1 1 0 001.414-1.414L9.414 11H13a1 1 0 100-2H9.414l1.293-1.293z" clipRule="evenodd" />
                  </svg>
                </label>
                <label htmlFor="carousel-2" className="inline-block text-red-600 cursor-pointer translate-x-5 bg-white rounded-full shadow-md active:translate-y-0.5">
                  {/* Next Button */}
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-8.707l-3-3a1 1 0 00-1.414 1.414L10.586 9H7a1 1 0 100 2h3.586l-1.293 1.293a1 1 0 101.414 1.414l3-3a1 1 0 000-1.414z" clipRule="evenodd" />
                  </svg>
                </label>
              </div>
            </div>
          </div>

          {/* Second Project */}
          <div>
            <input className="sr-only peer" type="radio" name="carousel" id="carousel-2" />
            <div className="w-96 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white rounded-lg shadow-lg transition-all duration-300 opacity-0 peer-checked:opacity-100 peer-checked:z-10 z-0">
              <img className="rounded-t-lg w-96 h-64" src="/image/img1.webp" alt="Desi Posh Ladies Outfit" />
              <div className="py-4 px-8">
                <h1 className="hover:cursor-pointer mt-2 text-gray-900 font-bold text-2xl tracking-tight">
                  ECommerce 
                </h1>
                <p className="hover:cursor-pointer py-3 text-gray-600 leading-6">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias deserunt ut voluptas asperiores quis praesentium commodi doloribus quam. Illum voluptas.
                </p>
              </div>
              {/* Controls */}
              <div className="absolute top-1/2 w-full flex justify-between z-20">
                <label htmlFor="carousel-1" className="inline-block text-red-600 cursor-pointer -translate-x-5 bg-white rounded-full shadow-md active:translate-y-0.5">
                  {/* Previous Button */}
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm.707-10.293a1 1 0 00-1.414-1.414l-3 3a1 1 0 000 1.414l3 3a1 1 0 001.414-1.414L9.414 11H13a1 1 0 100-2H9.414l1.293-1.293z" clipRule="evenodd" />
                  </svg>
                </label>
                <label htmlFor="carousel-3" className="inline-block text-red-600 cursor-pointer translate-x-5 bg-white rounded-full shadow-md active:translate-y-0.5">
                  {/* Next Button */}
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-8.707l-3-3a1 1 0 00-1.414 1.414L10.586 9H7a1 1 0 100 2h3.586l-1.293 1.293a1 1 0 101.414 1.414l3-3a1 1 0 000-1.414z" clipRule="evenodd" />
                  </svg>
                </label>
              </div>
            </div>
          </div>

          {/* Third Project */}
          <div>
            <input className="sr-only peer" type="radio" name="carousel" id="carousel-3" />
            <div className="w-96 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white rounded-lg shadow-lg transition-all duration-300 opacity-0 peer-checked:opacity-100 peer-checked:z-10 z-0">
              <img className="rounded-t-lg w-96 h-64" src="/image20.webp" alt="Cheezious Fast Food" />
              <div className="py-4 px-8">
                <h1 className="hover:cursor-pointer mt-2 text-gray-900 font-bold text-2xl tracking-tight">
                  Cheezious
                </h1>
                <p className="hover:cursor-pointer py-3 text-gray-600 leading-6">
                  Cheezious has marked its presence as one of the major fast-food brands. With the pride of being Pakistani at heart, it continues to compete at par with multinational brands that have been established and present for decades.
                </p>
              </div>
              {/* Controls */}
              <div className="absolute top-1/2 w-full flex justify-between z-20">
                <label htmlFor="carousel-2" className="inline-block text-blue-600 cursor-pointer -translate-x-5 bg-white rounded-full shadow-md active:translate-y-0.5">
                  {/* Previous Button */}
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm.707-10.293a1 1 0 00-1.414-1.414l-3 3a1 1 0 000 1.414l3 3a1 1 0 001.414-1.414L9.414 11H13a1 1 0 100-2H9.414l1.293-1.293z" clipRule="evenodd" />
                  </svg>
                </label>
                <label htmlFor="carousel-4" className="inline-block text-blue-600 cursor-pointer translate-x-5 bg-white rounded-full shadow-md active:translate-y-0.5">
                  {/* Next Button */}
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-8.707l-3-3a1 1 0 00-1.414 1.414L10.586 9H7a1 1 0 100 2h3.586l-1.293 1.293a1 1 0 101.414 1.414l3-3a1 1 0 000-1.414z" clipRule="evenodd" />
                  </svg>
                </label>
              </div>
            </div>
          </div>

          {/* Fourth Project */}
          <div>
            <input className="sr-only peer" type="radio" name="carousel" id="carousel-4" />
            <div className="w-96 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white rounded-lg shadow-lg transition-all duration-300 opacity-0 peer-checked:opacity-100 peer-checked:z-10 z-0">
              <img className="rounded-t-lg w-96 h-64" src="/himg12.webp" alt="Real Beauty Cream" />
              <div className="py-4 px-8">
                <h1 className="hover:cursor-pointer mt-2 text-gray-900 font-bold text-2xl tracking-tight">
                  Real Beauty Cream
                </h1>
                <p className="hover:cursor-pointer py-3 text-gray-600 leading-6">
                  Real beauty is far beyond skin-deep. This cream is formulated to bring out the best in your skin, ensuring it looks vibrant and youthful.
                </p>
              </div>
              {/* Controls */}
              <div className="absolute top-1/2 w-full flex justify-between z-20">
                <label htmlFor="carousel-3" className="inline-block text-green-600 cursor-pointer -translate-x-5 bg-white rounded-full shadow-md active:translate-y-0.5">
                  {/* Previous Button */}
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm.707-10.293a1 1 0 00-1.414-1.414l-3 3a1 1 0 000 1.414l3 3a1 1 0 001.414-1.414L9.414 11H13a1 1 0 100-2H9.414l1.293-1.293z" clipRule="evenodd" />
                  </svg>
                </label>
                <label htmlFor="carousel-5" className="inline-block text-green-600 cursor-pointer translate-x-5 bg-white rounded-full shadow-md active:translate-y-0.5">
                  {/* Next Button */}
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-8.707l-3-3a1 1 0 00-1.414 1.414L10.586 9H7a1 1 0 100 2h3.586l-1.293 1.293a1 1 0 101.414 1.414l3-3a1 1 0 000-1.414z" clipRule="evenodd" />
                  </svg>
                </label>
              </div>
            </div>
          </div>

          {/* Fifth Project */}
          <div>
            <input className="sr-only peer" type="radio" name="carousel" id="carousel-5" />
            <div className="w-96 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white rounded-lg shadow-lg transition-all duration-300 opacity-0 peer-checked:opacity-100 peer-checked:z-10 z-0">
              <img className="rounded-t-lg w-96 h-64" src="/img5.jpg" alt="New Project Image" />
              <div className="py-4 px-8">
                <h1 className="hover:cursor-pointer mt-2 text-gray-900 font-bold text-2xl tracking-tight">
               Mobile
                </h1>
                <p className="hover:cursor-pointer py-3 text-gray-600 leading-6">
                 Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur, veritatis. Harum inventore voluptatibus illo maxime a atque dicta molestiae nemo repudiandae, illum aliquid blanditiis.
                </p>
              </div>
              {/* Controls */}
              <div className="absolute top-1/2 w-full flex justify-between z-20">
                <label htmlFor="carousel-4" className="inline-block text-purple-600 cursor-pointer -translate-x-5 bg-white rounded-full shadow-md active:translate-y-0.5">
                  {/* Previous Button */}
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm.707-10.293a1 1 0 00-1.414-1.414l-3 3a1 1 0 000 1.414l3 3a1 1 0 001.414-1.414L9.414 11H13a1 1 0 100-2H9.414l1.293-1.293z" clipRule="evenodd" />
                  </svg>
                </label>
                <label htmlFor="carousel-1" className="inline-block text-purple-600 cursor-pointer translate-x-5 bg-white rounded-full shadow-md active:translate-y-0.5">
                  {/* Next Button */}
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-8.707l-3-3a1 1 0 00-1.414 1.414L10.586 9H7a1 1 0 100 2h3.586l-1.293 1.293a1 1 0 101.414 1.414l3-3a1 1 0 000-1.414z" clipRule="evenodd" />
                  </svg>
                </label>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default Project;
