// Cv.js
const Cv = () => {
    return (
        <div className="flex justify-center ">
            <img
                src="/image/Cv.jpeg"
                alt="CV"
                className="max-w-full h-auto" // Makes the image responsive
            />
           
        </div>
    )
}

export default Cv;
