
const Qualification = () => {
  return (
    <div>
      <section className="text-gray-600 body-font">
        <div className="p-4 sm:w-1/2 w-full mx-auto"> 
          <h2 className="title-font font-medium sm:text-4xl text-3xl text-gray-900 text-center pt-16">
          Education
          </h2>
       

          <div className="container flex flex-wrap px-5 py-24 mx-auto items-center justify-center"> 
            <div className="md:w-1/2 md:pr-12 md:py-8 md:border-r md:border-b-0 mb-10 md:mb-0 pb-10 border-b border-gray-200 text-center">
              <h1 className="sm:text-3xl text-2xl font-medium title-font mb-2 text-gray-900">Matric</h1>
              <p className="leading-relaxed text-base">
                Misali Zakariya Science School Arifwala
                <h1 className="px-20">2023</h1>
              </p>
            
            </div>
            <div className="flex flex-col md:w-1/2 md:pl-12 pt-8">
              <h2 className="sm:text-3xl text-2xl font-medium title-font mb-2 text-gray-900 ">Continue of Education in F.A.</h2>
              
              <nav className="flex flex-wrap list-none -mb-1">
                <li className="lg:w-1/3 mb-1 w-1/2">
                  <a className="text-gray-600 hover:text-gray-800">Allama Iqbal university Fasilabad </a>
                </li>
              </nav>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Qualification;
