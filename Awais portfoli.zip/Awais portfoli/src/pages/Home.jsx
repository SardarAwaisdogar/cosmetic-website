import { Button } from "@headlessui/react";
// import About from "./About";
import Contact from "./Contact";

import Qualification from "./Qualification";
import { FaLinkedin } from "react-icons/fa";
import { IoLogoGithub } from "react-icons/io";
import { FaFacebook } from "react-icons/fa";
import Skill from "./Skill";
import { Link } from "react-router-dom";

const Home = () => {
  return (
    <section className="text-gray-600 body-font overflow-hidden">
      <div>
        <div className="container px-5 py-24 mx-auto">
          <div className="lg:w-4/5 mx-auto flex flex-wrap">
            <div className="py-8">
              <div className="lg:w-1/2 w-full lg:pr-10 lg:py-6 mb-6 lg:mb-0">
                <h1 className="text-gray-900 text-3xl title-font font-medium mb-4">Welcome to My Portfolio</h1>
                <div className="flex mb-4">
                  <a className="flex-grow text-indigo-500 border-b-2 border-indigo-500 py-2 text-lg px-1 text-3xl title-font font-medium">
                    Hi, I'm Awais<span className="home" />
                  </a>
                </div>
                <p className="leading-relaxed mb-4">I'm Full stack web developer</p>
              </div>
              <h1 className="text-[#347928] text-3xl title-font font-medium ">Click on Icon</h1>
              <div className="flex space-x-4 pt-8">
                <a
                  href="https://www.linkedin.com/in/sardar-awais-dogar-748094325/"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="LinkedIn Profile"
                  className="text-indigo-500"
                >
                  <FaLinkedin size={30} />
                </a>
                <a
                  href="https://github.com/SardarAwaisdogar"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="GitHub Profile"
                  className="text-gray-600"
                >
                  <IoLogoGithub size={30} />
                </a>
                <a
                  href="https://www.facebook.com/profile.php?id=61550894788681"
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label="Facebook Profile"
                  className="text-indigo-500"
                >
                  <FaFacebook size={30} />
                </a>
                <div className="px-8 pt-12">
<Link to="/cv">
  <Button className="bg-indigo-800 text-white fs-8 px-4">
    Download CV
  </Button>
</Link>
</div>
              </div>
            </div>

            <img
              alt="A visual representation of my projects and skills"
              className="lg:w-1/2 w-full lg:h-auto h-64 object-cover object-center rounded home"
              src="/img4.jpg"
            />
          </div>
        </div>
        {/* <About /> */}
        <Skill/>
        <Qualification />

    
        <Contact />
      </div>
    </section>
  );
};

export default Home;