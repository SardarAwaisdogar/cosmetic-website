import React from 'react';

const Skill = () => {
  return (
    <div className="flex flex-col items-center">
      {/* Header Section */}
      <div className="p-4 sm:w-1/2 w-full">
        <h2 className="title-font font-medium sm:text-4xl text-3xl text-gray-900 text-center pt-16">
          SKILLS
        </h2>
        <p className="leading-relaxed text-center mt-4">
          My Technical Level
        </p>
      </div>

      {/* Skills Sections */}
      <section className="text-gray-600 body-font w-full">
        <div className="container px-5 py-24 mx-auto flex flex-col md:flex-row items-center">
          
          {/* Programming Languages */}
          <div className="md:w-1/2 md:pr-12 md:py-8 mb-10 md:mb-0">
            <h1 className="sm:text-3xl text-2xl font-medium title-font mb-4 text-gray-900 text-center md:text-left">
              Programming Languages
            </h1>
            <div className="flex flex-wrap">
              {["HTML", "CSS", "JavaScript", "ExpressJS", "TypeScript", "ReactJS"].map((skill) => (
                <div key={skill} className="p-2 sm:w-1/2 w-full">
                  <div className="bg-gray-100 rounded flex p-4 h-full items-center">
                    {/* Icon */}
                    <svg
                      fill="none"
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={3}
                      className="text-indigo-500 w-6 h-6 flex-shrink-0 mr-4"
                      viewBox="0 0 24 24"
                    >
                      <path d="M22 11.08V12a10 10 0 11-5.93-9.14" />
                      <path d="M22 4L12 14.01l-3-3" />
                    </svg>
                    <span className="title-font font-medium">{skill}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Technologies */}
          <div className="md:w-1/2 md:pl-12">
            <h1 className="sm:text-3xl text-2xl font-medium title-font mb-4 text-gray-900 text-center md:text-left">
              Technologies
            </h1>
            <div className="flex flex-wrap">
              {["Git", "GitHub", "MongoDB", "NextJS", "NodeJS", "TailwindCSS", "Bootstrap"].map((tech) => (
                <div key={tech} className="p-2 sm:w-1/2 w-full">
                  <div className="bg-gray-100 rounded flex p-4 h-full items-center">
                    {/* Icon */}
                    <svg
                      fill="none"
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={3}
                      className="text-indigo-500 w-6 h-6 flex-shrink-0 mr-4"
                      viewBox="0 0 24 24"
                    >
                      <path d="M22 11.08V12a10 10 0 11-5.93-9.14" />
                      <path d="M22 4L12 14.01l-3-3" />
                    </svg>
                    <span className="title-font font-medium">{tech}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
        </div>
      </section>
    </div>
  );
};

export default Skill;
