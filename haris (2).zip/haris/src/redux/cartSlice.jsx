import { createSlice } from "@reduxjs/toolkit";

const cartSlice = createSlice({
    name: "cart",
    initialState: {
        cartItems: [],
    },
    reducers: {
        addToCart: (state, action) => {
            const findindex = state.cartItems.findIndex((item)=>item.id === action.payload.id)
            if(findindex >= 0){
                state .cartItems[findindex].qty +=1;
            }else{
                let newentry = {...action.payload,qty:1};
                state.cartItems =[...state.cartItems,newentry];
            }
        },
     removesingle:(state, action)=>{
        const findindex = state.cartItems.findIndex((item)=>item.id === action.payload.id)
        if(state.cartItems[findindex].qty > 1){
            state.cartItems[findindex].qty -= 1;
        }
        },
        
        remove :(state, action)=>{
            const data = state.cartItems.filter((x)=>x.id !== action.payload.id)
            state.cartItems = data
        }
        
    },
})
export const {addToCart, removesingle, remove} = cartSlice.actions;
export default cartSlice.reducer;

