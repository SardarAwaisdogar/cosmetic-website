import { Carousel } from "@material-tailwind/react";

const Slider = () => {
  return (
 

   
    <Carousel className="rounded-xl">
      <img
        src="/slider1.webp"
        alt="image 1"
        className="h-full w-full object-cover"
      />
      <img
        src="/slider2.jpg"
        alt="image 2"
        className="h-full w-full object-cover"
      />
      <img
        src="/slider3.webp"
        alt="image 3"
        className="h-full w-full object-cover"
      />
    </Carousel>
  );
}
  

export default Slider
