import { Link } from "react-router-dom"
import Layout from "../component/Layout"
import { pizzadeal } from "../lib/pizzadeal"






const Pizzadeal = () => {
  return (
   <Layout>
 <section className="text-gray-600 body-font text-center">
  <div className="container px-5 py-24 mx-auto">
    
    <div className="flex flex-wrap -m-4">
   
   
      {pizzadeal.map((x)=>{
        return(
            <div className="xl:w-1/4 w-full md:w-1/2 p-4" key={x.id}>
        <div className="bg-gray-100 p-6 rounded-lg">
        <Link to={`/Pizzadeal/${x._id}`}><img className="h-40 rounded w-full object-cover object-center mb-6" src={x.image}alt="content" /></Link>
          <h3 className="tracking-widest text-indigo-500 text-xs font-medium title-font">SUBTITLE</h3>
          <h2 className="text-lg text-gray-900 font-medium title-font mb-4">{x.title.slice(0,15)}</h2>
          <p className="leading-relaxed text-base">{x.description.slice(0,40)}</p>
          <p className="leading-relaxed text-base">Rs:{x.price}</p>
          <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded" >
  Button
</button>
        </div>
        
      </div>
        )
      }
    
    )}
    </div>
  </div>
  <div>
<button>
<Link to={`/pizzaa`}><img className="h-40 rounded w-full object-cover object-center mb-6" src="/slider1.webp"alt="content" /></Link>

</button>
  </div>
</section>


   </Layout>
  )
}

export default Pizzadeal
