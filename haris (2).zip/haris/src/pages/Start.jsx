
import Herosection from '../auth/Herosection'
import Layout from '../component/Layout'


const Start = () => {
  return (
   <Layout>
    <Herosection/>

   </Layout>
  )
}

export default Start
