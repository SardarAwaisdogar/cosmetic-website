import { Route, Routes } from "react-router-dom"
import Start from "./pages/Start"

import Pizzadeal from "./pages/Pizzadeal"
import Pizzadealdetailpage from "./pages/Pizzadetailpage"
import Shoppingcart from "./pages/Shoppingcart"
import Sandwiches from "./pages/Sandwiches"
import Sandwichesdetail from "./pages/Sandwichesdetail"
import Pizzaa from "./pages/Pizzaa"








const App = () => {
  return (
    
      

   <Routes>
    <Route path="/" element={<Start/>}></Route>
    <Route path="/sandwiches" element={<Sandwiches/>}></Route>
    <Route path="/pizzadeal" element={<Pizzadeal/>}></Route>
    <Route path="/pizzadeal/:_id" element={<Pizzadealdetailpage/>}></Route>
    <Route path="/sandwichesdetail/:_id" element={<Sandwichesdetail/>}></Route>
    <Route path="/cart" element={<Shoppingcart/>}></Route>
    <Route path="/pizzaa" element={<Pizzaa/>}></Route>



    
  
   </Routes>
   
  )
}

export default App
