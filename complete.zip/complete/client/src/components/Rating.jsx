import React from 'react'

const Rating = (props) => {
    const {rating}= props;
  return (
    <div className='rating'>
        <span>
            <i className={`fa fa-star ${rating > 0? 'text-yellow-500': 'text-gray-400'}`}></i>
            <i className={`fa fa-star ${rating > 1? 'text-yellow-500': 'text-gray-400'}`}></i>
            <i className={`fa fa-star ${rating > 2? 'text-yellow-500': 'text-gray-400'}`}></i>
            <i className={`fa fa-star ${rating > 3? 'text-yellow-500': 'text-gray-400'}`}></i>
            <i className={`fa fa-star ${rating > 4? 'text-yellow-500': 'text-gray-400'}`}></i>
            <i className={`fa fa-star ${rating > 5? 'text-yellow-500': 'text-gray-400'}`}></i>
        </span>

        {/* <span style={{color: rating > 3? 'green': 'red'}}>{rating}</span>
        {Array.from({length: 5 - Math.floor(rating)}, (_, index) => (
            <i key={index} className={`fa fa-star ${rating > index + 1? 'text-yellow-500': 'text-gray-400'}`}></i>
        ))} */}
    </div>
  )
}

export default Rating
