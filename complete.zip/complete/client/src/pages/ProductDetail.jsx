import React, { useContext, useEffect, useReducer } from 'react';
import Layout from '../components/Layout';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import Loader from '../components/Loader';
import { Store } from '../store';

const ProductDetail = () => {
  const { slug } = useParams();
  
  const reducer = (state, action) => {
    switch (action.type) {
      case "GET_DATA":
        return { ...state, loading: true };
      case "GET_DATA_SUCCESS":
        return { ...state, loading: false, product: action.payload };
      case "GET_DATA_ERROR":
        return { ...state, loading: false, error: action.payload };
      default:
        return state;
    }
  };

  const [{ loading, error, product }, dispatch] = useReducer(reducer, {
    loading: false,
    error: null,
    product: {}
  });

  useEffect(() => {
    const fetchProduct = async () => {
      dispatch({ type: "GET_DATA" });
      try {
        const result = await axios.get(`http://localhost:5000/api/product/${slug}`);
        dispatch({ type: "GET_DATA_SUCCESS", payload: result.data });
      } catch (error) {
        dispatch({ type: "GET_DATA_ERROR", payload: error.message });
      }
    };

    fetchProduct();
  }, [slug]);

  const { state, dispatch: ctxDispatch } = useContext(Store);
  if (!state) {
    return null; // or any fallback UI
  }

  const {
    cart: { cartItems },
  } = state;

  const addToCartHandler = async (item) => {
    const existItem = cartItems.find((x) => x._id === product._id);
    const quantity = existItem ? existItem.quantity + 1 : 1;
    const { data } = await axios.get(`/api/products/${item._id}`);
    if (data.countInStock < quantity) {
      window.alert('Sorry. Product is out of stock');
      return;
    }
    ctxDispatch({
      type: 'CART_ADD_ITEM',
      payload: { ...item, quantity },
    });
  };

  return (
    <Layout>
      {loading ? (
        <Loader />
      ) : error ? (
        <div>{error}</div>
      ) : (
        <div className='grid grid-cols-2 shadow-lg rounded mt-20 w-[80%] mx-auto'>
          <div>
            <img src={product.image} alt={product.name} className='w-full object-contain'style={{aspectRatio:3/3, objectFit:"contain"}} />
          </div>
          <div className='pt-20'>
            <h1>{product.title}</h1>
            <p>{product.description}</p>
            <p>Price: ${product.price}</p>
            <p>Rating: {product.rating}</p>
            <p>Stock: {product.stock}</p>
            <p>Brand: {product.brand}</p>
            <p>Category: {product.category}</p>
            {product.countInStock === 0 ? (
          <button variant="light" disabled>
            Out of stock
          </button>
        ) : (
          <button onClick={() => addToCartHandler(product)} className=''>Add to cart</button>
        )}
          </div>
        </div>
      )}
    </Layout>
  );
};

export default ProductDetail;
