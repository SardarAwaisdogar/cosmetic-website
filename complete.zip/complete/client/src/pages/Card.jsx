import React from 'react'
import Rating from '../components/Rating';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';

const Card = (props) => {
    const { x } = props;
  return (
    <div className="xl:w-1/4 md:w-1/2 p-4 text-center cursor-pointer">
    <div className="bg-gray-100 p-6 rounded-lg ">
<Link to={`/product/${x.slug}`}>
<img className=" mb-6 hover:scale-[1.2] transition-all" src={x.image} alt="content" style={{aspectRatio:3/2, objectFit:"contain"}}/></Link>
      <h3 className="tracking-widest text-indigo-500 text-xs font-medium title-font">{x.title.slice(0,10)}</h3>
      <h2 className="text-lg text-gray-900 font-medium title-font mb-4">
      <Helmet>
      <title>{x.title}</title>
      </Helmet>
      </h2>
       <Rating rating={x.rating}/>
<div className='flex justify-between'>
<p className="leading-relaxed text-base">Original Price:<span className='line-through'>${x.price}</span></p>
<p className="leading-relaxed text-base">Discount_P:<span className='ml-2'>${Math.round(x.price*(1-x.discountPercentage/100))}</span></p>
</div>
    </div>
  </div>
  )
}

export default Card
