import React from 'react'
import Layout from '../components/Layout'

const Checkout = () => {
  return (
 <Layout>
 <div>
 <h1>Checkout</h1>
 <h2>Checkout Page</h2>
</div>
 </Layout>
  )
}

export default Checkout
