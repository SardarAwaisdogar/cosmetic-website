import { useContext } from 'react';
import { Helmet } from 'react-helmet-async';
import { Link, useNavigate } from 'react-router-dom';
import Layout from '../components/Layout';
import { Store } from '../store';
import axios from 'axios';

const ShoppingCard = () => {
  const navigate = useNavigate();
  const { state, dispatch: ctxDispatch } = useContext(Store);
  const {
    cart: { cartItems },
  } = state;

  const updateCartHandler = async (item, quantity) => {
    const { data } = await axios.get(`/api/products/${item._id}`);
    if (data.countInStock < quantity) {
      window.alert('Sorry. Product is out of stock');
      return;
    }
    ctxDispatch({
      type: 'CART_ADD_ITEM',
      payload: { ...item, quantity },
    });
  };

  const removeItemHandler = (item) => {
    ctxDispatch({ type: 'CART_REMOVE_ITEM', payload: item });
  };

  const checkoutHandler = () => {
    navigate('/signin?redirect=/shipping');
  };

  return (
    <Layout>
      <div className='mt-20 text-center '>
        <Helmet>
          <title>Shopping Cart</title>
        </Helmet>
        <h1 className="text-2xl font-bold mb-4">Shopping Cart</h1>
        <div className="flex flex-col md:flex-row mx-auto items-center justify-center w-[80%] shadow-lg border rounded-lg">
          <div className="md:w-2/3">
            {cartItems.length === 0 ? (
              <div className="alert alert-info">
                Cart is empty. <Link to="/product">Go Shopping</Link>
              </div>
            ) : (
              <ul className="divide-y divide-gray-200">
                {cartItems.map((item) => (
                  <li key={item._id} className="py-4 flex items-center">
                    <div className="md:w-1/4">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-full rounded"
                      />
                      <Link to={`/product/${item.slug}`} className="text-blue-500 hover:underline">
                        {item.name}
                      </Link>
                    </div>
                    <div className="md:w-1/4 flex items-center justify-center">
                      <button
                        onClick={() => updateCartHandler(item, item.quantity - 1)}
                        className="btn btn-light"
                        disabled={item.quantity === 1}
                      >
                        <i className="fas fa-minus-circle"></i>
                      </button>
                      <span className="mx-2">{item.quantity}</span>
                      <button
                        onClick={() => updateCartHandler(item, item.quantity + 1)}
                        className="btn btn-light"
                      >
                        <i className="fas fa-plus-circle"></i>
                      </button>
                    </div>
                    <div className="md:w-1/4 text-center">${item.price}</div>
                    <div className="md:w-1/4 flex items-center justify-center">
                      <button
                        onClick={() => removeItemHandler(item)}
                        className="btn btn-light"
                      >
                        <i className="fas fa-trash"></i>
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
          <div className="md:w-1/3 mt-4 md:mt-0 md:ml-4">
            <div className="card">
              <div className="card-body">
                <ul className="list-none p-0">
                  <li className="py-2">
                    <h3 className="text-lg font-bold">
                      Subtotal ({cartItems.reduce((a, c) => a + c.quantity, 0)} items) : $
                      {cartItems.reduce((a, c) => a + c.price * c.quantity, 0)}
                    </h3>
                  </li>
                  <li className="py-2">
                    <div className="flex justify-center">
                      <button
                        type="button"
                        className="btn btn-primary"
                        onClick={checkoutHandler}
                        disabled={cartItems.length === 0}
                      >
                        Proceed to Checkout
                      </button>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default ShoppingCard;
