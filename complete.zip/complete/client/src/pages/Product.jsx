import React, { useEffect, useReducer, useState } from 'react'
import Layout from '../components/Layout'
// import { product } from '../data/data'
import axios from 'axios'
import Card from './Card'
import logger from 'use-reducer-logger'

const Product = () => {
  const reducer = (state, action) => {
    switch (action.type) {
      case "GET DATA":
        return { ...state, loading: true };
      case "GET DATA SUCCESS":
        return { ...state, loading: false, products: action.payload };
      case "GET DATA ERROR":
        return { ...state, loading: false, error: action.payload };
      default:
        return state;
    }
  }

  const [{ loading, error, products }, dispatch] = useReducer(logger(reducer), {
    loading: false,
    error: null,
    products: []
  })

  useEffect(() => {
    const fetchProduct = async () => {
      dispatch({ type: "GET DATA" });
      try {
        const result = await axios.get("http://localhost:5000/api/product");
        dispatch({ type: "GET DATA SUCCESS", payload: result.data });
      } catch (error) {
        dispatch({ type: "GET DATA ERROR", payload: error.message });
      }
    }

    fetchProduct();
  }, []);

  return (
    <Layout>
      <section className="text-gray-600 body-font">
        <div className="container px-5 py-24 mx-auto">
          <div className="flex flex-wrap -m-4">
            {products && products.length > 0 ? (
              products.map((x) => (
                <Card key={x.id} x={x} />
              ))
            ) : (
              !loading && <p>No products available</p>
            )}
          </div>
        </div>
      </section>
    </Layout>
  )
}

export default Product;
