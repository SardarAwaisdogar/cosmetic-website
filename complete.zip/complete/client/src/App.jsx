
import './App.css'
import { Route, Routes } from 'react-router-dom'
import Home from './pages/Home'
import Product from './pages/Product'
import ProductDetail from './pages/ProductDetail'
import ShoppingCard from './pages/ShoppingCard'

function App() {


  return (
<div className=''>
<Routes>
<Route path='/' element={<Home/>}></Route>
<Route path='/product' element={<Product/>}></Route>
<Route path='/product/:slug' element={<ProductDetail/>}></Route>
<Route path='/cart' element={<ShoppingCard/>}></Route>

</Routes>

</div>

  )
}

export default App
