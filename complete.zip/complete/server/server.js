import express from 'express';
import dotenv from 'dotenv';
import { data } from './data.js';
dotenv.config();

import cors from 'cors'; // Middleware to handle cross-origin requests

const app = express();
app.use(cors())
// Middleware to parse JSON requests

app.use(express.json());


app.get('/api/product', (req, res) => {
    res.send(data)
  })
  app.get('/api/product/:slug', (req, res) => {
    const {slug } = req.params;
    const product = data.find(p => p.slug == slug);
    if(product){
        res.send(product)
    }else{
        res.status(404).send({message: 'Product not found'})
    }
  
  })

  app.get('/api/products/:id', (req, res) => {
    const product = data.find((x) => x._id === req.params.id);
    if (product) {
      res.send(product);
    } else {
      res.status(404).send({ message: 'Product Not Found' });
    }
  });


const port = process.env.PORT || 3000;

app.listen(port,()=>{
    console.log(`Server is running on port ${process.env.PORT}`)
})


